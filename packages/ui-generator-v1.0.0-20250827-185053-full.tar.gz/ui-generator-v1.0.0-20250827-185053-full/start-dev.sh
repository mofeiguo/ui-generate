#!/bin/bash
echo "🔧 开发模式启动 (使用本地dist目录)"
echo "================================"
./start.sh -dev
